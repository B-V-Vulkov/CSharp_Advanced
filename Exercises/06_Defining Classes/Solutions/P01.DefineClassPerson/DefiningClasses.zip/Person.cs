﻿namespace DefiningClasses
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
