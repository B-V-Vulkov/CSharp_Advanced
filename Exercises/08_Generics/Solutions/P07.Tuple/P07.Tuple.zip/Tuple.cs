﻿namespace P07.Tuple
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    class Tuple<T, V>
    {
        private T itam1;
        private V itam2;

        public Tuple(T itam1, V itam2)
        {
            this.itam1 = itam1;
            this.itam2 = itam2;
        }

        public string GetInfo()
        {
            return $"{this.itam1} -> {this.itam2}";
        }
    }
}
